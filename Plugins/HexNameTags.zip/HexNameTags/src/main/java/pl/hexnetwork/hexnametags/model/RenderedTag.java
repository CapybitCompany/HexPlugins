package pl.hexnetwork.hexnametags.model;

public final class RenderedTag {
    private final int entityId;
    private String signature;

    public RenderedTag(int entityId, String signature) {
        this.entityId = entityId;
        this.signature = signature;
    }

    public int entityId() {
        return entityId;
    }

    public String signature() {
        return signature;
    }

    public void signature(String signature) {
        this.signature = signature;
    }
}
