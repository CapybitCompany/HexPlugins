# HexNameTags 1.2.0 - zmiany

## Po 1.2.0

- Dodano `style.bottom-offset-y` z domyślną wartością `0.2`; opcja oznacza położenie dolnej krawędzi całego wieloliniowego napisu nad głową gracza.
- Pozycja TextDisplay jest teraz automatycznie przeliczana według liczby linii, aby dolna krawędź etykiety pozostawała na skonfigurowanej wysokości.
- Uproszczono zarządzanie liniami: używamy `/hexnametag set <gracz> <Linia 1 | Linia 2 | Linia 3>` do zastąpienia całej etykiety zamiast dodawania/usuwania pojedynczych linii.

## Komendy

- `/hexnametag set <gracz> <tekst>` teraz ustawia tag wskazanemu online graczowi, nie wykonującemu komendę.
- Dodano `/hexnametag self <tekst>` jako skrót do ustawiania własnego tagu.
- `/hexnametag clear [gracz]` usuwa tag wskazanego gracza albo własny tag, jeśli gracz nie został podany.
- `/hexnametag test [gracz]` pozwala testować tag nad wskazanym graczem.
- Dodano edycję linii:
  - `/hexnametag addline <gracz> <tekst>` / `append`
  - `/hexnametag prepend <gracz> <tekst>`
  - `/hexnametag insertline <gracz> <nr> <tekst>` / `insert`
  - `/hexnametag line <gracz> <nr> <tekst>` / `setline`
  - `/hexnametag removeline <gracz> <nr>` / `delline`
  - `/hexnametag show <gracz>` / `info`

## Widoczność

- Domyślne `show-own-tag` zmienione z `false` na `true`.
- Po ustawieniu/edycji tagu plugin wymusza natychmiastowe odświeżenie renderu, bez czekania na kolejny tick taska.
- Jeśli admin ustawia tag samemu sobie przy `show-own-tag=false`, komenda pokazuje ostrzeżenie.

## Baza danych

- `set`, `addline`, `prepend`, `insertline`, `line` zapisują finalną listę linii do DB przez HexCore.
- `clear` i usunięcie ostatniej linii usuwają wpis z DB przez HexCore.
